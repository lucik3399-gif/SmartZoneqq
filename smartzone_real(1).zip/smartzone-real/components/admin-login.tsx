'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export function AdminLogin() {
  const router = useRouter();
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleSubmit(formData: FormData) {
    setError('');
    setLoading(true);

    const response = await fetch('/api/admin/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(Object.fromEntries(formData.entries()))
    });

    if (!response.ok) {
      const data = await response.json();
      setError(data.message || 'Помилка входу');
      setLoading(false);
      return;
    }

    router.refresh();
    router.push('/admin/products');
  }

  return (
    <form action={handleSubmit} className="card mx-auto max-w-lg p-6">
      <div className="text-3xl font-black">Вхід в адмінку</div>
      <p className="mt-2 text-slate-600">Введіть логін і пароль адміністратора.</p>

      <div className="mt-6 space-y-4">
        <div>
          <label className="mb-2 block text-sm font-semibold">Логін</label>
          <input name="login" className="input" placeholder="admin" />
        </div>
        <div>
          <label className="mb-2 block text-sm font-semibold">Пароль</label>
          <input name="password" type="password" className="input" placeholder="••••••••" />
        </div>
      </div>

      <button type="submit" className="btn-primary mt-6 w-full" disabled={loading}>
        {loading ? 'Заходимо...' : 'Увійти'}
      </button>

      {error ? <div className="mt-4 rounded-2xl bg-rose-50 px-4 py-3 text-sm text-rose-600">{error}</div> : null}
    </form>
  );
}
