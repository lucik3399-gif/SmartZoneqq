'use client';

import { useState } from 'react';

export function CheckoutForm({ total }: { total: number }) {
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleSubmit(formData: FormData) {
    setLoading(true);
    setMessage('');

    const payload = Object.fromEntries(formData.entries());

    const response = await fetch('/api/checkout', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    const data = await response.json();
    setMessage(data.message);
    setLoading(false);
  }

  return (
    <form action={handleSubmit} className="card p-6">
      <div className="grid gap-4 md:grid-cols-2">
        <div>
          <label className="mb-2 block text-sm font-semibold">Ім'я та прізвище</label>
          <input name="name" required className="input" placeholder="Введіть ім'я" />
        </div>
        <div>
          <label className="mb-2 block text-sm font-semibold">Телефон</label>
          <input name="phone" required className="input" placeholder="+380..." />
        </div>
        <div>
          <label className="mb-2 block text-sm font-semibold">Місто</label>
          <input name="city" required className="input" placeholder="Ваше місто" />
        </div>
        <div>
          <label className="mb-2 block text-sm font-semibold">Доставка</label>
          <select name="delivery" className="input">
            <option>Нова пошта</option>
            <option>Укрпошта</option>
            <option>Самовивіз</option>
          </select>
        </div>
        <div className="md:col-span-2">
          <label className="mb-2 block text-sm font-semibold">Оплата</label>
          <select name="payment" className="input">
            <option>Оплата при отриманні</option>
            <option>Оплата карткою онлайн</option>
            <option>Переказ на картку</option>
          </select>
        </div>
        <div className="md:col-span-2">
          <label className="mb-2 block text-sm font-semibold">Коментар до замовлення</label>
          <textarea name="comment" className="input min-h-[120px]" placeholder="Наприклад: передзвонити після 18:00" />
        </div>
      </div>

      <div className="mt-6 flex items-center justify-between gap-3 rounded-3xl bg-slate-50 p-4">
        <div>
          <div className="text-sm text-slate-500">Сума до сплати</div>
          <div className="text-2xl font-black">{total.toLocaleString('uk-UA')} ₴</div>
        </div>
        <button type="submit" className="btn-primary" disabled={loading}>
          {loading ? 'Оформлюємо...' : 'Підтвердити замовлення'}
        </button>
      </div>

      {message ? <div className="mt-4 rounded-2xl bg-emerald-50 px-4 py-3 text-sm text-emerald-700">{message}</div> : null}
    </form>
  );
}
