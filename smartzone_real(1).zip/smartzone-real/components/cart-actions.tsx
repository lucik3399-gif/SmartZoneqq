'use client';

import { useRouter } from 'next/navigation';

async function updateCart(itemId: number, action: 'increment' | 'decrement' | 'remove') {
  await fetch('/api/cart', {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ itemId, action })
  });
}

export function CartActions({ itemId, qty }: { itemId: number; qty: number }) {
  const router = useRouter();

  return (
    <div className="flex items-center gap-2">
      <button
        className="h-10 w-10 rounded-xl bg-white font-bold ring-1 ring-slate-200"
        onClick={async () => {
          await updateCart(itemId, 'decrement');
          router.refresh();
        }}
      >
        −
      </button>
      <div className="min-w-8 text-center font-bold">{qty}</div>
      <button
        className="h-10 w-10 rounded-xl bg-white font-bold ring-1 ring-slate-200"
        onClick={async () => {
          await updateCart(itemId, 'increment');
          router.refresh();
        }}
      >
        +
      </button>
      <button
        className="rounded-2xl bg-rose-50 px-4 py-2 font-semibold text-rose-600"
        onClick={async () => {
          await updateCart(itemId, 'remove');
          router.refresh();
        }}
      >
        Видалити
      </button>
    </div>
  );
}
