'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import type { Product } from '@/lib/types';

export function AddToCartButton({ product }: { product: Product }) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  async function handleAdd() {
    setLoading(true);
    await fetch('/api/cart', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ product })
    });
    router.refresh();
    setLoading(false);
  }

  return (
    <button onClick={handleAdd} className="btn-primary w-full" disabled={loading}>
      {loading ? 'Додаємо...' : 'В кошик'}
    </button>
  );
}
