import { cookies } from 'next/headers';
import type { CartItem, Order, Product } from './types';

export const demoProducts: Product[] = [
  {
    id: 1,
    slug: 'iphone-15-pro-256',
    name: 'iPhone 15 Pro 256GB',
    price: 52999,
    oldPrice: 55999,
    category: 'Смартфони',
    badge: 'Хіт',
    image: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?auto=format&fit=crop&w=1200&q=80',
    description: 'Потужний преміум-смартфон для тих, хто хоче максимальну швидкість і камеру.',
    stock: 8
  },
  {
    id: 2,
    slug: 'samsung-galaxy-s24-256',
    name: 'Samsung Galaxy S24 256GB',
    price: 38999,
    oldPrice: 41999,
    category: 'Смартфони',
    badge: 'Акція',
    image: 'https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?auto=format&fit=crop&w=1200&q=80',
    description: 'Флагман Samsung із яскравим дисплеєм, камерою та потужною батареєю.',
    stock: 14
  },
  {
    id: 3,
    slug: 'xiaomi-14-512',
    name: 'Xiaomi 14 512GB',
    price: 29999,
    oldPrice: 32999,
    category: 'Смартфони',
    badge: 'Топ ціна',
    image: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=1200&q=80',
    description: 'Вигідний смартфон із великим обсягом памʼяті та хорошою продуктивністю.',
    stock: 16
  },
  {
    id: 4,
    slug: 'airpods-pro-2',
    name: 'AirPods Pro 2',
    price: 9999,
    oldPrice: 11499,
    category: 'Аксесуари',
    badge: 'Популярне',
    image: 'https://images.unsplash.com/photo-1606220588913-b3aacb4d2f46?auto=format&fit=crop&w=1200&q=80',
    description: 'Бездротові навушники з активним шумозаглушенням.',
    stock: 20
  },
  {
    id: 5,
    slug: 'apple-watch-series-9',
    name: 'Apple Watch Series 9',
    price: 18999,
    oldPrice: 20999,
    category: 'Гаджети',
    badge: 'Новинка',
    image: 'https://images.unsplash.com/photo-1579586337278-3befd40fd17a?auto=format&fit=crop&w=1200&q=80',
    description: 'Розумний годинник для спорту, сповіщень та щоденного комфорту.',
    stock: 11
  },
  {
    id: 6,
    slug: 'power-bank-20000',
    name: 'Power Bank 20000 mAh',
    price: 1499,
    oldPrice: 1899,
    category: 'Аксесуари',
    badge: 'Must have',
    image: 'https://images.unsplash.com/photo-1609091839311-d5365f9ff1c5?auto=format&fit=crop&w=1200&q=80',
    description: 'Ємний павербанк для поїздок, роботи і щоденного використання.',
    stock: 32
  }
];

export function formatPrice(value: number) {
  return `${value.toLocaleString('uk-UA')} ₴`;
}

export async function getProducts(): Promise<Product[]> {
  return demoProducts;
}

export async function getProductBySlug(slug: string) {
  return demoProducts.find((product) => product.slug === slug) ?? null;
}

export async function getFeaturedProducts() {
  return demoProducts.slice(0, 4);
}

export async function getCart(): Promise<CartItem[]> {
  const raw = (await cookies()).get('smartzone-cart')?.value;
  if (!raw) return [];

  try {
    return JSON.parse(raw) as CartItem[];
  } catch {
    return [];
  }
}

export async function getCartCount() {
  const items = await getCart();
  return items.reduce((sum, item) => sum + item.qty, 0);
}

export async function getCartTotal() {
  const items = await getCart();
  return items.reduce((sum, item) => sum + item.qty * item.price, 0);
}

export async function getDemoOrders(): Promise<Order[]> {
  return [
    {
      id: '#1024',
      customer_name: 'Дмитро',
      phone: '+380671112233',
      city: 'Рівне',
      delivery: 'Нова пошта',
      payment: 'Оплата при отриманні',
      comment: '',
      total: 18999,
      status: 'В обробці',
      created_at: '2026-03-13 12:10'
    },
    {
      id: '#1023',
      customer_name: 'Олена',
      phone: '+380501234567',
      city: 'Львів',
      delivery: 'Укрпошта',
      payment: 'Оплата карткою онлайн',
      comment: 'Передзвонити після 18:00',
      total: 52999,
      status: 'Підтверджено',
      created_at: '2026-03-13 10:45'
    },
    {
      id: '#1022',
      customer_name: 'Іван',
      phone: '+380931111111',
      city: 'Київ',
      delivery: 'Нова пошта',
      payment: 'Переказ на картку',
      comment: '',
      total: 9999,
      status: 'Відправлено',
      created_at: '2026-03-12 17:30'
    }
  ];
}
