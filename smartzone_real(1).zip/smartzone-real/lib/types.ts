export type Product = {
  id: number;
  slug: string;
  name: string;
  price: number;
  oldPrice?: number;
  category: string;
  badge?: string;
  image: string;
  description: string;
  stock: number;
};

export type CartItem = Product & { qty: number };

export type Order = {
  id: string;
  customer_name: string;
  phone: string;
  city: string;
  delivery: string;
  payment: string;
  comment: string;
  total: number;
  status: string;
  created_at: string;
};
