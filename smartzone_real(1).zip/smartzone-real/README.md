# SmartZone Real

Готовий стартовий проект для магазину SmartZone на Next.js + Supabase.

## Що вже є

- Next.js App Router структура
- Tailwind CSS стилі
- головна сторінка
- каталог товарів
- сторінка товару
- cookie-based кошик
- checkout форма
- адмін-вхід
- сторінки товарів і замовлень для адмінки
- SQL схема для Supabase

## Швидкий запуск

```bash
npm install
cp .env.example .env.local
npm run dev
```

## Що заповнити в `.env.local`

```env
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
ADMIN_LOGIN=admin
ADMIN_PASSWORD=change-this-password
```

## Де що знаходиться

- `app/` — сторінки та API routes
- `components/` — UI компоненти
- `lib/data.ts` — демо-дані та допоміжні функції
- `supabase-schema.sql` — таблиці для products / orders / order_items

## Що зробити далі для повного бою

1. Підключити реальне читання товарів із Supabase.
2. Зберігати checkout у таблицю `orders`.
3. Зберігати позиції замовлення в `order_items`.
4. Зробити CRUD для товарів в адмінці.
5. Додати справжню Supabase Auth авторизацію.
6. Залити проект на Vercel.
