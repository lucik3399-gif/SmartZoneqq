create table if not exists public.products (
  id bigint generated always as identity primary key,
  slug text unique not null,
  name text not null,
  description text not null default '',
  category text not null,
  price integer not null,
  old_price integer,
  badge text,
  image text not null,
  stock integer not null default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id bigint generated always as identity primary key,
  customer_name text not null,
  phone text not null,
  city text not null,
  delivery text not null,
  payment text not null,
  comment text not null default '',
  total integer not null,
  status text not null default 'new',
  created_at timestamptz not null default now()
);

create table if not exists public.order_items (
  id bigint generated always as identity primary key,
  order_id bigint not null references public.orders(id) on delete cascade,
  product_id bigint references public.products(id) on delete set null,
  product_name text not null,
  price integer not null,
  qty integer not null check (qty > 0)
);
