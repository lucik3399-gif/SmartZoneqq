import './globals.css';
import type { Metadata } from 'next';
import Link from 'next/link';
import { ShoppingCart, ShieldCheck, Smartphone } from 'lucide-react';
import { getCartCount } from '@/lib/data';

export const metadata: Metadata = {
  title: 'SmartZone',
  description: 'Бойовий магазин смартфонів та аксесуарів'
};

export default async function RootLayout({
  children
}: Readonly<{
  children: React.ReactNode;
}>) {
  const cartCount = await getCartCount();

  return (
    <html lang="uk">
      <body>
        <header className="sticky top-0 z-50 border-b border-slate-200 bg-white/95 backdrop-blur">
          <div className="container-shell flex items-center justify-between py-4">
            <Link href="/" className="flex items-center gap-3">
              <div className="rounded-2xl bg-slate-900 p-3 text-white">
                <Smartphone size={20} />
              </div>
              <div>
                <div className="text-lg font-black">SmartZone</div>
                <div className="text-xs text-slate-500">Смартфони, гаджети, аксесуари</div>
              </div>
            </Link>

            <nav className="hidden items-center gap-2 md:flex">
              <Link href="/" className="btn-secondary">Головна</Link>
              <Link href="/catalog" className="btn-secondary">Каталог</Link>
              <Link href="/cart" className="btn-secondary">Кошик</Link>
              <Link href="/checkout" className="btn-secondary">Оформлення</Link>
              <Link href="/admin" className="btn-secondary">Адмінка</Link>
            </nav>

            <Link href="/cart" className="btn-primary gap-2">
              <ShoppingCart size={18} />
              Кошик ({cartCount})
            </Link>
          </div>
        </header>

        {children}

        <footer className="mt-16 border-t border-slate-200 bg-white">
          <div className="container-shell grid gap-6 py-10 md:grid-cols-4">
            <div>
              <div className="text-xl font-black">SmartZone</div>
              <p className="mt-3 text-sm text-slate-600">
                Готова бойова база для запуску магазину на Next.js + Supabase.
              </p>
            </div>
            <div>
              <div className="font-bold">Покупцям</div>
              <div className="mt-3 space-y-2 text-sm text-slate-600">
                <div>Каталог</div>
                <div>Доставка і оплата</div>
                <div>Гарантія</div>
              </div>
            </div>
            <div>
              <div className="font-bold">Контакти</div>
              <div className="mt-3 space-y-2 text-sm text-slate-600">
                <div>+380 (XX) XXX-XX-XX</div>
                <div>smartzone.store.ua@gmail.com</div>
                <div>Україна</div>
              </div>
            </div>
            <div className="space-y-3 text-sm text-slate-600">
              <div className="flex items-center gap-2"><ShieldCheck size={16} /> Next.js App Router</div>
              <div className="flex items-center gap-2"><ShieldCheck size={16} /> Supabase база даних</div>
              <div className="flex items-center gap-2"><ShieldCheck size={16} /> Vercel-ready</div>
            </div>
          </div>
        </footer>
      </body>
    </html>
  );
}
