import Image from 'next/image';
import Link from 'next/link';
import { getFeaturedProducts, formatPrice } from '@/lib/data';
import { AddToCartButton } from '@/components/add-to-cart-button';

export default async function HomePage() {
  const products = await getFeaturedProducts();

  return (
    <main>
      <section className="container-shell grid gap-8 py-10 md:grid-cols-2 md:py-14">
        <div className="flex flex-col justify-center">
          <div className="mb-4 inline-flex w-fit rounded-full bg-emerald-100 px-4 py-2 text-sm font-semibold text-emerald-700">
            Реально бойова версія SmartZone
          </div>
          <h1 className="text-4xl font-black leading-tight md:text-6xl">
            Магазин смартфонів, гаджетів і аксесуарів для справжнього запуску
          </h1>
          <p className="mt-5 max-w-xl text-base text-slate-600 md:text-lg">
            Ця база вже має каталог, кошик, checkout, адмін-вхід і готову структуру для Supabase.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link href="/catalog" className="btn-primary">Перейти в каталог</Link>
            <Link href="/admin" className="btn-secondary">Відкрити адмінку</Link>
          </div>
          <div className="mt-8 grid grid-cols-3 gap-3">
            <div className="card p-5"><div className="text-sm text-slate-500">Товарів</div><div className="mt-2 text-2xl font-bold">1200+</div></div>
            <div className="card p-5"><div className="text-sm text-slate-500">Доставка</div><div className="mt-2 text-2xl font-bold">1-2 дні</div></div>
            <div className="card p-5"><div className="text-sm text-slate-500">Гарантія</div><div className="mt-2 text-2xl font-bold">12 міс</div></div>
          </div>
        </div>

        <div className="relative overflow-hidden rounded-[32px] bg-slate-900 p-5 shadow-xl">
          <Image
            src="https://images.unsplash.com/photo-1510557880182-3d4d3cba35a5?auto=format&fit=crop&w=1400&q=80"
            alt="SmartZone hero"
            width={1400}
            height={1000}
            className="h-full min-h-[380px] w-full rounded-[28px] object-cover opacity-90"
          />
          <div className="absolute bottom-8 left-8 max-w-sm rounded-3xl bg-white/95 p-5 shadow-lg">
            <div className="text-sm font-semibold text-emerald-600">SmartZone Premium</div>
            <div className="mt-2 text-2xl font-black">Готово під Next.js + Supabase</div>
            <div className="mt-2 text-sm text-slate-600">Швидкий старт для реального магазину.</div>
          </div>
        </div>
      </section>

      <section className="container-shell pb-6">
        <div className="grid gap-4 md:grid-cols-4">
          {[
            ['Офіційна якість', 'Перевірені товари та гарантія'],
            ['Швидка доставка', 'Нова пошта та самовивіз'],
            ['Зручна оплата', 'Готівка, картка, післяплата'],
            ['Підтримка', 'Допомога з вибором телефону']
          ].map(([title, sub]) => (
            <div key={title} className="card p-5">
              <div className="text-lg font-bold">{title}</div>
              <div className="mt-2 text-sm text-slate-600">{sub}</div>
            </div>
          ))}
        </div>
      </section>

      <section className="container-shell py-6 md:py-8">
        <div className="mb-6 flex items-center justify-between gap-3">
          <div>
            <h2 className="text-3xl font-black">Популярні товари</h2>
            <p className="mt-1 text-slate-600">Перші товари для запуску магазину</p>
          </div>
          <Link href="/catalog" className="btn-secondary">Увесь каталог</Link>
        </div>

        <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
          {products.map((product) => (
            <div key={product.id} className="overflow-hidden rounded-[30px] bg-white shadow-sm ring-1 ring-black/5">
              <div className="relative">
                <Image src={product.image} alt={product.name} width={900} height={700} className="h-64 w-full object-cover" />
                <div className="absolute left-4 top-4 rounded-full bg-white px-3 py-1 text-xs font-bold shadow">
                  {product.badge}
                </div>
              </div>
              <div className="p-5">
                <div className="text-sm font-medium text-slate-500">{product.category}</div>
                <h3 className="mt-1 text-xl font-bold leading-snug">{product.name}</h3>
                <div className="mt-4 flex items-end gap-3">
                  <div className="text-2xl font-black">{formatPrice(product.price)}</div>
                  {product.oldPrice ? <div className="text-sm text-slate-400 line-through">{formatPrice(product.oldPrice)}</div> : null}
                </div>
                <div className="mt-5 grid gap-3">
                  <Link href={`/product/${product.slug}`} className="btn-secondary w-full">Детальніше</Link>
                  <AddToCartButton product={product} />
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}
