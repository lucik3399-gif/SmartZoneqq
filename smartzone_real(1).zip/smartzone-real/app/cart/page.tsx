import Link from 'next/link';
import { CartActions } from '@/components/cart-actions';
import { formatPrice, getCart, getCartCount, getCartTotal } from '@/lib/data';

export default async function CartPage() {
  const cart = await getCart();
  const count = await getCartCount();
  const total = await getCartTotal();

  return (
    <main className="container-shell py-8">
      <div className="mb-6">
        <h1 className="text-4xl font-black">Кошик</h1>
        <p className="mt-2 text-slate-600">Керування товарами та сума замовлення.</p>
      </div>

      {cart.length === 0 ? (
        <div className="card p-10 text-center">
          <div className="text-2xl font-bold">У кошику поки немає товарів</div>
          <p className="mt-2 text-slate-600">Додай товари з каталогу SmartZone.</p>
          <Link href="/catalog" className="btn-primary mt-5">Перейти в каталог</Link>
        </div>
      ) : (
        <div className="grid gap-6 lg:grid-cols-[1.5fr_0.8fr]">
          <div className="space-y-4">
            {cart.map((item) => (
              <div key={item.id} className="card flex flex-col gap-4 p-4 md:flex-row">
                <img src={item.image} alt={item.name} className="h-36 w-full rounded-3xl object-cover md:w-40" />
                <div className="flex-1">
                  <div className="text-sm text-slate-500">{item.category}</div>
                  <div className="mt-1 text-xl font-bold">{item.name}</div>
                  <div className="mt-3 text-lg font-black">{formatPrice(item.price)}</div>
                </div>
                <div className="flex items-center md:items-start">
                  <CartActions itemId={item.id} qty={item.qty} />
                </div>
              </div>
            ))}
          </div>

          <div className="card h-fit p-6">
            <div className="text-2xl font-black">Підсумок</div>
            <div className="mt-5 space-y-3 text-slate-600">
              <div className="flex items-center justify-between"><span>Товарів</span><span>{count}</span></div>
              <div className="flex items-center justify-between"><span>Доставка</span><span>За тарифами перевізника</span></div>
              <div className="flex items-center justify-between border-t border-slate-200 pt-3 text-lg font-black text-slate-900"><span>Разом</span><span>{formatPrice(total)}</span></div>
            </div>
            <Link href="/checkout" className="btn-primary mt-6 w-full">Перейти до оформлення</Link>
          </div>
        </div>
      )}
    </main>
  );
}
