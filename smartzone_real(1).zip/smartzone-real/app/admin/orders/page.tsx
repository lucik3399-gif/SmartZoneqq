import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { formatPrice, getDemoOrders } from '@/lib/data';

export default async function AdminOrdersPage() {
  const isAuthorized = (await cookies()).get('smartzone-admin')?.value === 'authorized';
  if (!isAuthorized) redirect('/admin');

  const orders = await getDemoOrders();

  return (
    <main className="container-shell py-8">
      <div className="mb-6">
        <h1 className="text-4xl font-black">Замовлення</h1>
        <p className="mt-2 text-slate-600">Список замовлень. Для бойового запуску підключи таблицю orders в Supabase.</p>
      </div>

      <div className="space-y-4">
        {orders.map((order) => (
          <div key={order.id} className="card p-5">
            <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
              <div>
                <div className="text-xl font-black">{order.id}</div>
                <div className="mt-2 text-slate-600">{order.customer_name} • {order.phone} • {order.city}</div>
                <div className="mt-1 text-sm text-slate-500">{order.delivery} • {order.payment}</div>
                <div className="mt-1 text-sm text-slate-500">{order.created_at}</div>
              </div>
              <div className="rounded-2xl bg-emerald-50 px-4 py-2 text-sm font-semibold text-emerald-700">{order.status}</div>
            </div>
            <div className="mt-4 text-2xl font-black">{formatPrice(order.total)}</div>
            {order.comment ? <div className="mt-2 text-sm text-slate-600">Коментар: {order.comment}</div> : null}
          </div>
        ))}
      </div>
    </main>
  );
}
