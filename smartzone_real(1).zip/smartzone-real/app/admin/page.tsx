import { cookies } from 'next/headers';
import Link from 'next/link';
import { AdminLogin } from '@/components/admin-login';

export default async function AdminPage() {
  const isAuthorized = (await cookies()).get('smartzone-admin')?.value === 'authorized';

  if (!isAuthorized) {
    return (
      <main className="container-shell py-10">
        <AdminLogin />
      </main>
    );
  }

  return (
    <main className="container-shell py-8">
      <div className="mb-6 flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
        <div>
          <h1 className="text-4xl font-black">Адмін-панель SmartZone</h1>
          <p className="mt-2 text-slate-600">Керуйте товарами та замовленнями.</p>
        </div>
        <div className="rounded-2xl bg-emerald-50 px-4 py-3 text-sm font-semibold text-emerald-700">Вхід виконано</div>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <div className="card p-5"><div className="text-sm text-slate-500">Товари</div><div className="mt-2 text-2xl font-bold">126</div></div>
        <div className="card p-5"><div className="text-sm text-slate-500">Замовлення</div><div className="mt-2 text-2xl font-bold">18</div></div>
        <div className="card p-5"><div className="text-sm text-slate-500">Клієнти</div><div className="mt-2 text-2xl font-bold">342</div></div>
        <div className="card p-5"><div className="text-sm text-slate-500">Дохід</div><div className="mt-2 text-2xl font-bold">284 900 ₴</div></div>
      </div>

      <div className="mt-6 grid gap-4 md:grid-cols-2">
        <Link href="/admin/products" className="card p-6 transition hover:-translate-y-1">
          <div className="text-2xl font-black">Товари</div>
          <div className="mt-2 text-slate-600">Додавання, редагування, видалення, ціни та залишки.</div>
        </Link>
        <Link href="/admin/orders" className="card p-6 transition hover:-translate-y-1">
          <div className="text-2xl font-black">Замовлення</div>
          <div className="mt-2 text-slate-600">Перегляд статусів, клієнтів і сум замовлень.</div>
        </Link>
      </div>
    </main>
  );
}
