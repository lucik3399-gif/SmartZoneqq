import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { formatPrice, getProducts } from '@/lib/data';

export default async function AdminProductsPage() {
  const isAuthorized = (await cookies()).get('smartzone-admin')?.value === 'authorized';
  if (!isAuthorized) redirect('/admin');

  const products = await getProducts();

  return (
    <main className="container-shell py-8">
      <div className="mb-6 flex items-center justify-between gap-3">
        <div>
          <h1 className="text-4xl font-black">Товари</h1>
          <p className="mt-2 text-slate-600">Демо-таблиця товарів. Наступний крок — підключення Supabase CRUD.</p>
        </div>
        <button className="btn-primary">+ Додати товар</button>
      </div>

      <div className="space-y-3">
        {products.map((product) => (
          <div key={product.id} className="card flex flex-col gap-4 p-4 md:flex-row md:items-center">
            <img src={product.image} alt={product.name} className="h-20 w-full rounded-2xl object-cover md:w-24" />
            <div className="flex-1">
              <div className="font-bold">{product.name}</div>
              <div className="text-sm text-slate-500">{product.category}</div>
            </div>
            <div className="font-black">{formatPrice(product.price)}</div>
            <div className="text-sm text-slate-500">Залишок: {product.stock}</div>
            <div className="flex gap-2">
              <button className="btn-secondary">Редагувати</button>
              <button className="rounded-2xl bg-rose-50 px-4 py-3 font-semibold text-rose-600">Видалити</button>
            </div>
          </div>
        ))}
      </div>
    </main>
  );
}
