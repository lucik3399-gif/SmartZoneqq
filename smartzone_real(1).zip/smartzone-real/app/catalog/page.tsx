import Image from 'next/image';
import Link from 'next/link';
import { AddToCartButton } from '@/components/add-to-cart-button';
import { formatPrice, getProducts } from '@/lib/data';

export default async function CatalogPage() {
  const products = await getProducts();

  return (
    <main className="container-shell py-8">
      <div className="mb-6">
        <h1 className="text-4xl font-black">Каталог товарів</h1>
        <p className="mt-2 text-slate-600">Готовий каталог для реального запуску.</p>
      </div>

      <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
        {products.map((product) => (
          <div key={product.id} className="overflow-hidden rounded-[30px] bg-white shadow-sm ring-1 ring-black/5">
            <Image src={product.image} alt={product.name} width={900} height={700} className="h-64 w-full object-cover" />
            <div className="p-5">
              <div className="text-sm font-medium text-slate-500">{product.category}</div>
              <h2 className="mt-1 text-xl font-bold">{product.name}</h2>
              <div className="mt-4 flex items-end gap-3">
                <div className="text-2xl font-black">{formatPrice(product.price)}</div>
                {product.oldPrice ? <div className="text-sm text-slate-400 line-through">{formatPrice(product.oldPrice)}</div> : null}
              </div>
              <p className="mt-4 text-sm text-slate-600">{product.description}</p>
              <div className="mt-5 grid gap-3">
                <Link href={`/product/${product.slug}`} className="btn-secondary w-full">Детальніше</Link>
                <AddToCartButton product={product} />
              </div>
            </div>
          </div>
        ))}
      </div>
    </main>
  );
}
