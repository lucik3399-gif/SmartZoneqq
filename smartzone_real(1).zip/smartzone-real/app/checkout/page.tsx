import { CheckoutForm } from '@/components/checkout-form';
import { formatPrice, getCart, getCartTotal } from '@/lib/data';

export default async function CheckoutPage() {
  const cart = await getCart();
  const total = await getCartTotal();

  return (
    <main className="container-shell py-8">
      <div className="mb-6">
        <h1 className="text-4xl font-black">Оформлення замовлення</h1>
        <p className="mt-2 text-slate-600">Форма для реального магазину.</p>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.2fr_0.8fr]">
        <CheckoutForm total={total} />

        <div className="card h-fit p-6">
          <div className="text-2xl font-black">Ваше замовлення</div>
          <div className="mt-4 space-y-3">
            {cart.length === 0 ? (
              <div className="rounded-2xl bg-slate-100 p-4 text-slate-600">Кошик порожній. Додайте товари перед оформленням.</div>
            ) : (
              cart.map((item) => (
                <div key={item.id} className="flex items-center justify-between gap-3 border-b border-slate-100 pb-3">
                  <div>
                    <div className="font-semibold">{item.name}</div>
                    <div className="text-sm text-slate-500">Кількість: {item.qty}</div>
                  </div>
                  <div className="font-bold">{formatPrice(item.qty * item.price)}</div>
                </div>
              ))
            )}
          </div>
          <div className="mt-5 flex items-center justify-between border-t border-slate-200 pt-4 text-lg font-black">
            <span>Разом</span>
            <span>{formatPrice(total)}</span>
          </div>
        </div>
      </div>
    </main>
  );
}
