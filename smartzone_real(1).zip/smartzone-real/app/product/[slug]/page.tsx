import Image from 'next/image';
import { notFound } from 'next/navigation';
import { AddToCartButton } from '@/components/add-to-cart-button';
import { formatPrice, getProductBySlug } from '@/lib/data';

export default async function ProductPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const product = await getProductBySlug(slug);

  if (!product) notFound();

  return (
    <main className="container-shell py-8">
      <div className="grid gap-6 lg:grid-cols-2">
        <div className="overflow-hidden rounded-[32px] bg-white p-4 shadow-sm ring-1 ring-black/5">
          <Image src={product.image} alt={product.name} width={1400} height={1100} className="h-full min-h-[450px] w-full rounded-[28px] object-cover" />
        </div>
        <div className="card p-6">
          <div className="text-sm font-semibold text-emerald-600">{product.badge}</div>
          <h1 className="mt-2 text-4xl font-black">{product.name}</h1>
          <div className="mt-4 text-sm text-slate-500">Категорія: {product.category}</div>
          <div className="mt-5 flex items-end gap-3">
            <div className="text-3xl font-black">{formatPrice(product.price)}</div>
            {product.oldPrice ? <div className="text-sm text-slate-400 line-through">{formatPrice(product.oldPrice)}</div> : null}
          </div>
          <p className="mt-5 text-slate-600">{product.description}</p>
          <div className="mt-5 rounded-3xl bg-slate-50 p-4 text-sm text-slate-600">
            Залишок на складі: <span className="font-bold text-slate-900">{product.stock} шт.</span>
          </div>
          <div className="mt-6 max-w-sm">
            <AddToCartButton product={product} />
          </div>
        </div>
      </div>
    </main>
  );
}
