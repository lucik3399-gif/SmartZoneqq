import { cookies } from 'next/headers';
import { NextResponse } from 'next/server';

export async function POST(request: Request) {
  const body = await request.json();
  const cart = (await cookies()).get('smartzone-cart')?.value;

  if (!cart) {
    return NextResponse.json({ message: 'Кошик порожній.' }, { status: 400 });
  }

  if (!body.name || !body.phone || !body.city) {
    return NextResponse.json({ message: 'Заповніть імʼя, телефон і місто.' }, { status: 400 });
  }

  (await cookies()).set('smartzone-cart', '[]', { path: '/' });

  return NextResponse.json({
    message:
      'Замовлення прийнято. Для бойового запуску підключіть Supabase таблицю orders і збереження в базу.'
  });
}
