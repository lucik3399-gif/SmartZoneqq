import { cookies } from 'next/headers';
import { NextResponse } from 'next/server';

export async function POST(request: Request) {
  const { login, password } = await request.json();

  const validLogin = process.env.ADMIN_LOGIN;
  const validPassword = process.env.ADMIN_PASSWORD;

  if (!validLogin || !validPassword) {
    return NextResponse.json({ message: 'Адмін-дані не налаштовані в .env.local' }, { status: 500 });
  }

  if (login !== validLogin || password !== validPassword) {
    return NextResponse.json({ message: 'Невірний логін або пароль' }, { status: 401 });
  }

  (await cookies()).set('smartzone-admin', 'authorized', {
    httpOnly: true,
    sameSite: 'lax',
    path: '/'
  });

  return NextResponse.json({ ok: true });
}
