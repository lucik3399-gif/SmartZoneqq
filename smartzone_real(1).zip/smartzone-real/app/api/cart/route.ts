import { cookies } from 'next/headers';
import { NextResponse } from 'next/server';
import type { CartItem, Product } from '@/lib/types';

async function readCart(): Promise<CartItem[]> {
  const raw = (await cookies()).get('smartzone-cart')?.value;
  if (!raw) return [];

  try {
    return JSON.parse(raw) as CartItem[];
  } catch {
    return [];
  }
}

async function writeCart(items: CartItem[]) {
  (await cookies()).set('smartzone-cart', JSON.stringify(items), {
    httpOnly: false,
    sameSite: 'lax',
    path: '/'
  });
}

export async function POST(request: Request) {
  const { product }: { product: Product } = await request.json();
  const items = await readCart();
  const existing = items.find((item) => item.id === product.id);

  const nextItems = existing
    ? items.map((item) => (item.id === product.id ? { ...item, qty: item.qty + 1 } : item))
    : [...items, { ...product, qty: 1 }];

  await writeCart(nextItems);
  return NextResponse.json({ ok: true });
}

export async function PATCH(request: Request) {
  const { itemId, action }: { itemId: number; action: 'increment' | 'decrement' | 'remove' } = await request.json();
  const items = await readCart();

  let nextItems = items;

  if (action === 'remove') {
    nextItems = items.filter((item) => item.id !== itemId);
  }

  if (action === 'increment') {
    nextItems = items.map((item) => (item.id === itemId ? { ...item, qty: item.qty + 1 } : item));
  }

  if (action === 'decrement') {
    nextItems = items
      .map((item) => (item.id === itemId ? { ...item, qty: item.qty - 1 } : item))
      .filter((item) => item.qty > 0);
  }

  await writeCart(nextItems);
  return NextResponse.json({ ok: true });
}
